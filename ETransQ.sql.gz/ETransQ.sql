-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2016 at 04:05 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ETransQ`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `admin_id` int(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Branches`
--

CREATE TABLE `Branches` (
  `branch_id` varchar(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `branch_head_firstname` text NOT NULL,
  `branch_head_lastname` text NOT NULL,
  `address_line1` text NOT NULL,
  `address_line2` varchar(50) NOT NULL,
  `pincode` int(10) NOT NULL,
  `red_date` date NOT NULL,
  `state_id` varchar(30) NOT NULL,
  `city_id` int(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `office_no` int(15) NOT NULL,
  `fax` int(20) NOT NULL,
  `mobile` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `City`
--

CREATE TABLE `City` (
  `city_id` int(20) NOT NULL,
  `city_name` varchar(20) NOT NULL,
  `state_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Events`
--

CREATE TABLE `Events` (
  `event_id` int(20) NOT NULL,
  `event_name` varchar(20) NOT NULL,
  `event_summary` varchar(30) NOT NULL,
  `event_date` date NOT NULL,
  `publish_date` date NOT NULL,
  `city` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

CREATE TABLE `Feedback` (
  `feedback_id` int(20) NOT NULL,
  `feedback_by_name` varchar(20) NOT NULL,
  `feedback_by_no` int(20) NOT NULL,
  `feedback_by_designation` varchar(20) NOT NULL,
  `feedback_by_company` varchar(20) NOT NULL,
  `feedback_by_email` varchar(30) NOT NULL,
  `feedback` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `News`
--

CREATE TABLE `News` (
  `news_id` int(20) NOT NULL,
  `news_line` varchar(30) NOT NULL,
  `news_summary` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Notification`
--

CREATE TABLE `Notification` (
  `notification_id` varchar(100) NOT NULL,
  `notification_about` varchar(100) NOT NULL,
  `notification_date` date NOT NULL,
  `notification_viewed` varchar(1000) NOT NULL,
  `notification_for` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Offer`
--

CREATE TABLE `Offer` (
  `offer_id` int(20) NOT NULL,
  `branch_id` int(20) NOT NULL,
  `offer_date` date NOT NULL,
  `start_route` varchar(30) NOT NULL,
  `destination_route` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `publish_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Offer_booking`
--

CREATE TABLE `Offer_booking` (
  `booking_id` int(10) NOT NULL,
  `offer_id` int(20) NOT NULL,
  `date` date NOT NULL,
  `offer_booked_by` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Pincode`
--

CREATE TABLE `Pincode` (
  `pincode_id` int(20) NOT NULL,
  `city_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Routes`
--

CREATE TABLE `Routes` (
  `route_id` int(20) NOT NULL,
  `source` varchar(20) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `State`
--

CREATE TABLE `State` (
  `state_id` int(10) NOT NULL,
  `state_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Suggest_associate`
--

CREATE TABLE `Suggest_associate` (
  `suggestion_id` int(20) NOT NULL,
  `associate_id` int(20) NOT NULL,
  `suggested_by_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Tender`
--

CREATE TABLE `Tender` (
  `tender_id` varchar(100) NOT NULL,
  `branch_id` varchar(100) NOT NULL,
  `tender_publishDate` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `city` varchar(100) NOT NULL,
  `cost` int(100) NOT NULL,
  `summary` varchar(100) NOT NULL,
  `city_id` int(100) NOT NULL,
  `hits` int(100) NOT NULL,
  `tender_heading` varchar(100) NOT NULL,
  `publish_status` varchar(1000) NOT NULL,
  `tender_file` varchar(100) NOT NULL,
  `spam_count` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Testimonial`
--

CREATE TABLE `Testimonial` (
  `testimonial_id` int(20) NOT NULL,
  `testimonial` varchar(100) NOT NULL,
  `testimonial_by` varchar(20) NOT NULL,
  `testimonial_for` varchar(20) NOT NULL,
  `publish_status` varchar(1) NOT NULL,
  `request_date` date NOT NULL,
  `publish_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `user_id` int(30) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `organisation_name` text NOT NULL,
  `privacy_office` varchar(20) NOT NULL,
  `privacy_personal` varchar(20) NOT NULL,
  `privacy_fax` varchar(20) NOT NULL,
  `privacy_website` varchar(30) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `reg_date` date NOT NULL,
  `user_status` varchar(30) NOT NULL,
  `adminblock` int(20) NOT NULL,
  `featured_client` bit(1) NOT NULL,
  `photo` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User_associate`
--

CREATE TABLE `User_associate` (
  `associate_id` int(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  `friend_1` varchar(20) NOT NULL,
  `user_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Vehicle_requirement`
--

CREATE TABLE `Vehicle_requirement` (
  `req_offer_id` int(30) NOT NULL,
  `start` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `rate` int(30) NOT NULL,
  `summary` varchar(100) NOT NULL,
  `req_published_by` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Veh_req_Booking`
--

CREATE TABLE `Veh_req_Booking` (
  `veh_req_Booking_id` varchar(100) NOT NULL,
  `summary` text NOT NULL,
  `booked_by` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Via_station`
--

CREATE TABLE `Via_station` (
  `route_id` int(20) NOT NULL,
  `city_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `Branches`
--
ALTER TABLE `Branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `City`
--
ALTER TABLE `City`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `Events`
--
ALTER TABLE `Events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `Feedback`
--
ALTER TABLE `Feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `News`
--
ALTER TABLE `News`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `Notification`
--
ALTER TABLE `Notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `Offer`
--
ALTER TABLE `Offer`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `Offer_booking`
--
ALTER TABLE `Offer_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `Pincode`
--
ALTER TABLE `Pincode`
  ADD PRIMARY KEY (`pincode_id`);

--
-- Indexes for table `Routes`
--
ALTER TABLE `Routes`
  ADD PRIMARY KEY (`route_id`);

--
-- Indexes for table `State`
--
ALTER TABLE `State`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `Suggest_associate`
--
ALTER TABLE `Suggest_associate`
  ADD PRIMARY KEY (`suggestion_id`);

--
-- Indexes for table `Tender`
--
ALTER TABLE `Tender`
  ADD PRIMARY KEY (`tender_id`);

--
-- Indexes for table `Testimonial`
--
ALTER TABLE `Testimonial`
  ADD PRIMARY KEY (`testimonial_id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `User_associate`
--
ALTER TABLE `User_associate`
  ADD PRIMARY KEY (`associate_id`);

--
-- Indexes for table `Vehicle_requirement`
--
ALTER TABLE `Vehicle_requirement`
  ADD PRIMARY KEY (`req_offer_id`);

--
-- Indexes for table `Veh_req_Booking`
--
ALTER TABLE `Veh_req_Booking`
  ADD PRIMARY KEY (`veh_req_Booking_id`);

--
-- Indexes for table `Via_station`
--
ALTER TABLE `Via_station`
  ADD PRIMARY KEY (`route_id`,`city_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
